var searchData=
[
  ['input_4',['input',['../structinput.html',1,'']]],
  ['inputdata_5',['InputData',['../_solve_square_8c.html#a10b7a9d0ced8576ab56ca404c0311d1a',1,'InputData(double *ptr_a, double *ptr_b, double *ptr_c):&#160;SolveSquare.c'],['../_solve_square_8h.html#a789813dfcd3cf7d9dff3df916d83f9ef',1,'InputData(double *a, double *b, double *c):&#160;SolveSquare.c']]],
  ['iszero_6',['isZero',['../_solve_square_8c.html#a72f9e3f1ac3e22071bdcdd823010b63b',1,'isZero(const double a):&#160;SolveSquare.c'],['../_solve_square_8h.html#a72f9e3f1ac3e22071bdcdd823010b63b',1,'isZero(const double a):&#160;SolveSquare.c']]]
];
