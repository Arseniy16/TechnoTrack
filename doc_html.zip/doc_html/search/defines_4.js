var searchData=
[
  ['undef_51',['UNDEF',['../_solve_square_8h.html#abde25a67f4046530ae1c572cefeb5869',1,'SolveSquare.h']]]
];
