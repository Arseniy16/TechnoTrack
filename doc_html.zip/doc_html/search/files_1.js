var searchData=
[
  ['solvesquare_2ec_30',['SolveSquare.c',['../_solve_square_8c.html',1,'']]],
  ['solvesquare_2eh_31',['SolveSquare.h',['../_solve_square_8h.html',1,'']]]
];
