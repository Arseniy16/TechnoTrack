var searchData=
[
  ['mistake_47',['MISTAKE',['../_solve_square_8h.html#ad2290f1bc8fc9e7e12fde3fcc19a7712',1,'SolveSquare.h']]]
];
