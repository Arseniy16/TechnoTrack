var searchData=
[
  ['b_42',['b',['../structinput.html#a79e10c16e841b84aff10326f893fdc8c',1,'input']]]
];
