var searchData=
[
  ['two_5froots_19',['TWO_ROOTS',['../_solve_square_8h.html#a6f1e9c68fa0701faf267d04bb07a0d90',1,'SolveSquare.h']]]
];
