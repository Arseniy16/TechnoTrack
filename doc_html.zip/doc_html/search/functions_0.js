var searchData=
[
  ['compare_5fvalue_34',['compare_value',['../_unit_test_8c.html#a45fb7b9d9fe7112bb1cf1a0ab52808c1',1,'compare_value(const double x1):&#160;UnitTest.c'],['../_unit_test_8h.html#ad25d65dbb29f9fad0e57e0611726525d',1,'compare_value(const double x):&#160;UnitTest.c']]]
];
