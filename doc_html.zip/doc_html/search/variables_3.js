var searchData=
[
  ['res_44',['res',['../structoutput.html#ae0aa46ab8a624f20696124e0e2a40f96',1,'output']]]
];
