var searchData=
[
  ['solvelinear_15',['SolveLinear',['../_solve_square_8c.html#a0461013c77716ef7230ab69ef0f23823',1,'SolveLinear(const double b, const double c, double *x):&#160;SolveSquare.c'],['../_solve_square_8h.html#a96a7d6a5993fe11188cbf6525f8690c4',1,'SolveLinear(const double a, const double b, double *x):&#160;SolveSquare.c']]],
  ['solvesquare_16',['SolveSquare',['../_solve_square_8c.html#a437de28e08bb409d9c278cd1f505f7b9',1,'SolveSquare(const double a, const double b, const double c, double *x1, double *x2):&#160;SolveSquare.c'],['../_solve_square_8h.html#a437de28e08bb409d9c278cd1f505f7b9',1,'SolveSquare(const double a, const double b, const double c, double *x1, double *x2):&#160;SolveSquare.c']]],
  ['solvesquare_2ec_17',['SolveSquare.c',['../_solve_square_8c.html',1,'']]],
  ['solvesquare_2eh_18',['SolveSquare.h',['../_solve_square_8h.html',1,'']]]
];
